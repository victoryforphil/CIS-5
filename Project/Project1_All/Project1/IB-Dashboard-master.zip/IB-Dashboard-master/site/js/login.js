


var errorBox = document.getElementById("error-alert");
var successBox = document.getElementById("success-alert");
clearError();
function clearError(){
    errorBox.style.display = "none";
}
clearSuccess();
function clearSuccess(){
    successBox.style.display = "none";
}
function showError(message){
    errorBox.style.display = "block";
    errorBox.innerHTML = message;
}
function showSuccess(message){
    successBox.style.display = "block";
    successBox.innerHTML = message;
}
/*
function onSignup(){
    clearError();
    clearSuccess();
    var email = document.getElementById("signupEmail").value;
    var password1 = document.getElementById("signupPassword1").value;
    var password2 = document.getElementById("signupPassword2").value;

    
    if(!email || email == "" || email.length < 3 || !email.includes("@")){
        return showError("Please Enter a Valid Email Address!");
    }

    if(!password1 || password1 == "" || password1.length < 5){
        return showError("Please Enter a Valid Password!");
    }

    if(!password2 || password2 == "" || password2.length < 5){
        return showError("Please Enter your Password Again!");
    }

    if(password1 != password2){
        return showError("Passwords do not match!");
    }

    // Send Request
    axios.post("http://localhost:7001/auth/signup",{email:email, password:password1}).then((resp)=>{
        console.log(resp.data);
        if(resp.data.type == "ERR"){
            return showError(resp.data.message);
        }

        return showSuccess(resp.data.message);
    }).catch((err)=>{
        showError(err.message);
    });
    return;
}
*/
loadMemory();
function loadMemory(){
    
    document.getElementById("inputEmail").value = localStorage.getItem("login-email");
}
function onLogin(){
    clearError();
    clearSuccess();
    var email = document.getElementById("inputEmail").value;
    var password = document.getElementById("inputPassword").value;
    localStorage.setItem("login-email", email);
    
    if(!email || email == "" || email.length < 3 || !email.includes("@")){
        return showError("Please Enter a Valid Email Address!");
    }

    if(!password || password == "" || password.length < 5){
        return showError("Please Enter a Valid Password!");
    }

    // Send Request
    axios.post(API_ROUTE + "/auth/login",{email:email, password:password}).then((resp)=>{
        console.log(resp.data);
        if(resp.data.type == "ERR"){
            return showError(resp.data.message);
        }
        showSuccess(resp.data.message);
        return window.location.href  = "/dashboard.html";
    }).catch((err)=>{
        showError(err.message);
    });
    return;
}