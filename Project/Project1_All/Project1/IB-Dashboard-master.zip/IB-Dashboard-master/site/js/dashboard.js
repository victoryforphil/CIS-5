//State Vars

var alertBox = document.getElementById("alert-box");

var userDropdown = document.getElementById("accountDropdown")


resetAlerts();
loadUser();
getChannels();


function showAlert(isError, message) {
    if (isError) {
        alertBox.className = "alert alert-danger"
    } else {
        alertBox.className = "alert alert-success"
    }
    alertBox.innerHTML = message;
    alertBox.style.display = "block";
}

function resetAlerts() {
    alertBox.style.display = "none";
}



function showToast(message) {

}



function loadLocalStorage() {

}

function updateLocalStorage() {

}


function loadUser() {
    axios.get(API_ROUTE + "auth/user").then((res) => {
        var response = res.data;
        console.log(res)
        if (response.type == "ERR") {
            showAlert(true, response.message);
            if (response.code == "AUTH_FAILED") { // user Not logged in
                // Redirect them to the login page
               // window.location.href = "/index.html";
            }
        } else {
            userDropdown.innerHTML = response.data.email;
        }
    }).catch(err => {
        showAlert(true, err.message)
    })
}

var options = {
    shouldSort: true,
    threshold: 0.6,
    location: 0,
    distance: 30,
    maxPatternLength: 32,
    minMatchCharLength: 1,
    keys: [
        "name",

    ]
};

var fuse = undefined;
var chans = []
function getChannels() {
    axios.get(API_ROUTE + "/rev").then((res) => {
        var response = res.data;
        console.log(res)
        if (response.type == "ERR") {
            showAlert(true, response.message);
            if (response.code == "AUTH_FAILED") { // user Not logged in
                // Redirect them to the login page
               // window.location.href = "/index.html";
            }
        } else {
            chans = response.data;
            fuse = new Fuse(chans, options); // "list" is the item array
        }
    }).catch(err => {
        showAlert(true, err.message)
    })
}


var preSearch = [
    {
        id:"UCfuQHdNwJTa_E1ExHoEUwTw",
        name: "CCM - 찬양모음"
    },
    {
        id:"UCaTvrHqmyJV52NqA8datjBQ",
        name: "Puppies TV"
    },
    {
        id:"UC5ggtACLoJ3Ro8RNNgKfcvA",
        name: "Cute VN"
    },
    {
        id:"UCVCYPSYZ8jjYz_V5OOOi3rQ",
        name: "CuteVN Animals"
    },
    {
        id:"UCkDeZafHkxsqOY1Sr4vKsRg",
        name: "Oscar Guerra"
    },
    {
        id:"UCwvz9MqJHji1Twr86YDP_1A",
        name: "Tumblr Reads"
    },
    {
        id:"UCJllB47kdk2brq4zj6_593g",
        name: "Corey & Crawford"
    },
    {
        id:"UCF8GLutz3FQDwsbLI-Q6WSw",
        name: "Corey La Barrie"
    },
    {
        id:"UC_GTfKEd3uZRbfIW5v57arw",
        name: "10-Minutes Cakes"
    },
    {
        id:"UCt8gGXU0AZ3KECTfr1BwRCg",
        name: "Survival Cooking"
    },
    {
        id:"UCGiCrx-yIf1Ggo_4vZc7JGw",
        name: "Survival Cooking Skills"
    },
    {
        id:"UCPQUIgYWSdE19Ac6iZH0fYw",
        name: "Top Yummy"
    },
    {
        id:"UCPyXaNnvtIMnJ_VSgYlXIVw",
        name: "Mr. Cakes"
    },
    {
        id:"UC22LjJxl3n71-bw8cJGKdQw",
        name: "Cake Lovers"
    },
    {
        id:"4P07Rf2BMQJD7N_Tx3Q",
        name: "RELAX - 寝かしつけ 音楽"
    },
    {
        id:"UCxNFziH75JGG0qQvV8V1E9w",
        name: "赤ちゃん 寝る 音楽 - 子守唄 BGM"
    },
    {
        id:"UCHBXStCavwkNt8XbvGbZtaw",
        name: "放鬆音樂 - Relaxing Music Sleep"
    }

]


updateSearch(preSearch)
function onSearch() {
    var query = document.getElementById("channel-search").value;
    if(query.length < 1){
     updateSearch(preSearch);
     return
    }
    var result = fuse.search(query);

    result = result.slice(0, 5)
    updateSearch(result);

}
function updateSearch(result){
    var resTable = document.getElementById("search-result");
    resTable.innerHTML = ""
    result.forEach((channel) => {
        var string = `<tr>
        <td>${channel.name}</td>
        <td>${channel.id}</td>
        <td><button type="button" class="btn btn-success" onclick="getRev('${channel.id}')">Get Data</button></td>
         </tr>`

        resTable.innerHTML += string;
    })
}

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'Daily Revenue Logged (USD)',
            data: []
        }]
    }
});

function getRev(id) {
    window.scrollTo(0,0);
    showAlert(false, "Loading...");
    axios.get(API_ROUTE + "/rev/" + id).then((res) => {
        var response = res.data;
        console.log(res)
        if (response.type == "ERR") {
            showAlert(true, response.message);
            if (response.code == "AUTH_FAILED") { // user Not logged in
                // Redirect them to the login page
                //window.location.href = "/index.html";
            }
        } else {

           
            const list = document.getElementById("rev-table");
            list.innerHTML = "";

            var peroid = [];

            var now = new Date();
            var daysAfterLastThursday = (-7 + 4) - now.getDay(); // 7 = number of days in week, 4 = the thursdayIndex (0= sunday)
            var currentMs = now.getTime();
            var lastThursday = new Date(currentMs + (daysAfterLastThursday * 24 * 60 * 60 * 1000));
           
            $('#myTab a[href="#results"]').tab('show')

            var total = 0;
            myChart.data.labels = []
            myChart.data.datasets[0].data = [];
            for(var i=0;i<7;i++){
                var listDate = new Date();
                listDate.setDate(lastThursday.getDate() + i);
                var revForDay = undefined;
                
                myChart.data.labels.push((listDate.getMonth() + 1) + "/" + listDate.getDate())
                for(var j=0;j<response.data.length;j++){
                    var earning = response.data[j]
                    var earningDate = new Date(parseInt(earning.day));
                    myChart.data.labels
                    console.log(earningDate.getDate() + " _ " + listDate.getDate());
                    
                    if(earningDate.getDate() == listDate.getDate() && earningDate.getMonth() == listDate.getMonth()){
                        revForDay = earning.revenue;

                        
                    }
                };
                console.log(revForDay);
                
                if(revForDay){
                    myChart.data.datasets[0].data.push(revForDay)
                    total += parseFloat(revForDay);
                    list.innerHTML +=
                    `<tr>
                    <td>${listDate.getMonth() + 1}/${listDate.getDate()}</td>
                    <td>☑️</td>
                    <td>$${revForDay}</td>
                    <td>❌</td>
                    </tr>`
                }else{
                    list.innerHTML +=
                    `<tr>
                    <td>${listDate.getMonth() + 1}/${listDate.getDate()}</td>
                    <td>❌</td>
                    <td>N/A</td>
                    <td>✅</td>
                    </tr>`
                }
                
            }
            document.getElementById("rev-last").innerHTML = "Total (Thurs->Thurs): $" + total.toFixed(2)


            var day = 0;
            resetAlerts();
            /*
             // Select tab by name
            response.data.forEach((earning) => {
                day++;
                list.innerHTML +=
                    `<tr>
                    <td>${new Date(earning.date).getMonth() + 1}/${new Date(earning.date).getDate()}</td>
                    <td>$${earning.value}</td>
                    <td>$${(earning.value * 0.2).toFixed(2)}</td>
                    </tr>`
            })*/
        }
    }).catch(err => {
        showAlert(true, err.message)
    })
}