const Logger = require("disnode-logger").static;
const Passport = require("passport");
const LocalStrategy = require('passport-local').Strategy;
const DB = require("../utils/db");
const GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
const bcrypt = require("bcryptjs");
const config = require("../config")
module.exports.passport = Passport;

module.exports.usePassport = (app) => {
    Logger.Info("AuthHandler", "usePassport", "Using Passport JS");
    app.use(Passport.initialize());
    app.use(Passport.session());

    Passport.serializeUser(function (user, cb) {
       
        Logger.Success("AuthHandler", "serializeUser", "Serialized User: " + user.id);
        cb(null, user.id);
    });
    Passport.deserializeUser(function (id, cb) {
        
        DB.FindOne("users", { "id": id }).then((result) => {
            Logger.Success("AuthHandler", "deserializeUser", "Deserialized User: " + id);
            
            
            cb(null, result);
        }).catch((err) => {
            
            cb(err, null);
            Logger.Error("AuthHandler", "deserializeUser", "Error Deserializing id: " + id + ", " + err);
        })
    });

    setupLocal();
}


function setupLocal() {
    Logger.Info("AuthHandler", "setupLocal", "Setting up local auth");


    Passport.use("google-login",new GoogleStrategy({
        clientID: config.google.clientId,
        clientSecret: config.google.clientSecret,
        callbackURL: config.google.callbackURL
      },
      function(accessToken, refreshToken, profile, done) {
           DB.Update("users",{"id": profile.id},profile).then((res)=>{
               return done(null,profile)
           }).catch((err)=>{
               Logger.Error("AuthHandler", "google-login", "Failed to update DB: " + err)
               return done(err, profile);
           })
      }
    ))
    
}

function genPass(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8));
}

function comparePass(passwordEntered, userPassword) {
    return bcrypt.compareSync(passwordEntered, userPassword);
}