const Logger = require("disnode-logger").static;
const Passport = require("passport");
const LocalStrategy = require('passport-local').Strategy;
const sqlDb = require("../utils/sql")
const bcrypt = require("bcryptjs")
module.exports.passport = Passport;

module.exports.usePassport = (app) => {
    Logger.Info("AuthHandler", "usePassport", "Using Passport JS");
    app.use(Passport.initialize());
    app.use(Passport.session());

    Passport.serializeUser(function (user, cb) {
       
        Logger.Success("AuthHandler", "serializeUser", "Serialized User: " + user["id"]);
        cb(null, user["id"]);
    });
    Passport.deserializeUser(function (id, cb) {
        var query = `SELECT * from ib_login
        WHERE id='${id}'
        `;
        sqlDb.query("gas_data", query).then((result) => {
            result = result[0]
            
            Logger.Success("AuthHandler", "deserializeUser", "Deserialized User: " + id);
            cb(null, result);
        }).catch((err) => {
            cb(err, null);
            Logger.Error("AuthHandler", "deserializeUser", "Error Deserializing id: " + id + ", " + err);
        })
    });

    setupLocal();
}


function setupLocal() {
    Logger.Info("AuthHandler", "setupLocal", "Setting up local auth");
    
    Passport.use("local-signup", new LocalStrategy({
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    },
        function (req, email, password, done) {
            var accountInfo = {
                name: req.body.name,
                company: req.body.company,
                mobileNumbers: req.body.number,
                country: req.body.country
            };
            email = email.toLowerCase();
            DB.FindOne("users", { "email": email }).then((result) => {
                if (result) {
                    Logger.Warning("AuthHandler", "local-signup", "User Already Exists: " + email);
                    return done({code:"SIGNUP_USER_EXISTS", message:"That email address is already taken"}, false, req.flash('signupMessage', 'That email is already taken.'));
                }

                DB.Insert("users", {
                    email: email,
                    password: genPass(password),
                    info: accountInfo,
                    created: new Date()
                });

                Logger.Success("AuthHandler", "local-signup", "Created user for: " + email);
                return done(null, result);
            }).catch((err) => {
                Logger.Error("AuthHandler", "local-signup", "Failed to auth: " + err)
                return done(err, null);
            })


        }
    ));

    Passport.use("local-login", new LocalStrategy({
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    },
        function (req,email, password, done) {
            email = email.toLowerCase();
            
            
            var query = `SELECT * from ib_login
            WHERE email='${email}'
            `;
            sqlDb.query("gas_data",query).then((result) => {
                console.log(result);
                result = result[0]
                if (!result) {
                    Logger.Warning("AuthHandler", "local-login", "No DB result for: " + email);
                    return done({code: "LOGIN_EMAIL_NOT_FOUND",message:"Could not find user with email: " + email}, false);
                }
                
                if (!comparePass(password, result.password)) {
                    Logger.Warning("AuthHandler", "local-login", "Incorrect Password for: " + email);
                    return done({code: "LOGIN_INCORRECT_PASSWORD",message:"Incorrect Password"}, false);
                }

               
                Logger.Success("AuthHandler", "local-login", "Auth'd: " + email);
                return done(null, result);
            }).catch((err) => {
                Logger.Error("AuthHandler", "local-login", "Failed to auth: " + err)
                return done(err);
            })


        }
    ));
}

function genPass(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8));
}

function comparePass(passwordEntered, userPassword) {
    return bcrypt.compareSync(passwordEntered, userPassword);
}
