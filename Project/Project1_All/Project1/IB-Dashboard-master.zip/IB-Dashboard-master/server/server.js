//Alex Carter - Disnode Development Group - 11/27/2019

// ======== //
// REQUIRES //
// ======== //
const Logger = require("disnode-logger").static;
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session')
const cookieParser = require('cookie-parser')
const path = require('path');
const cors = require('cors')

const sql = require("./utils/sql")
const config = require("./config")
const app = express();
const flash = require('connect-flash');



Logger.Info("Server", "StartUp/DB", "Connecting to Database");
async function sqlConnect(){
  await sql.connect("client_data", config);
  await sql.connect("gas_data", config);

}

sqlConnect();

app.use(session({
  secret: config.secret,
  resave: true,
  saveUninitialized: false,

  cookie: {
    _expires : 60000000,
    maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
  },

}));
const AuthHandler = require("./handlers/AuthHandler")
AuthHandler.usePassport(app);
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());
app.use(cookieParser())
app.use(flash());
/*
var Rollbar = require("rollbar");
var rollbar = new Rollbar({
  accessToken: "4b0969b7ca3048738dfa6165f8cdfb98",
  captureUncaught: true,
  captureUnhandledRejections: true
});
*/

function httpLogger(req, res, next) {
  var start = Date.now();
  Logger.Success("HTTP Request", `${req.method} ${req.url}`, "Resonding with: " + res.statusCode)
  next();
}

app.use(httpLogger);

// ======= //
// ROUTES  //
// ======= //


var AuthRoutes = require("./routes/AuthRoutes");
app.use('/auth', AuthRoutes);

var RevenueRoutes = require("./routes/RevenueRoutes");
app.use('/rev', RevenueRoutes);

app.get('/status', function (req, res) {
  Logger.Info("Server", "Route: /_ah/health ", "Sending Health Status.");
  res.send('Online. Sever Time: ' + new Date());
})

if (config.staticHost) {
  Logger.Info("Server", 'Static Host', "Starting Static Host")
  app.use('/', express.static("site"))
}

app.listen(config.port, function () {
  Logger.Success("Server", "Start", "Server Listening on port: " + config.port)

})

