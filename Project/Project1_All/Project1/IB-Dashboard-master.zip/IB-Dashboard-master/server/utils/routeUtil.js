module.exports.isLoggedIn = (req, res, next) => {

    // if user is authenticated in the session, carry on 
    if (req.isAuthenticated())
        return next();

    // if they aren't redirect them to the home page
    const reply = {
        type: "ERR",
        code: "AUTH_FAILED",
        message: "This route you are not authorized for.",
        data: req.isAuthenticated()
    }
    return res.json(reply).status(402);
}