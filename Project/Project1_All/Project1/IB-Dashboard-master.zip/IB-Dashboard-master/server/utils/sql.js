var mysql = require('mysql');
var Log = require("disnode-logger").static;

var connections = {};

module.exports.connect = (db,config) => {
    return new Promise((res, rej) => {
        Log.Info("DB", "connect", "Connecting to Refinery SQL at: " + config.sql.host + " / " + db)
        config.sql.database = db;

        connections[db] = mysql.createConnection(config.sql);

        connections[db].connect(function (err) {
            if (err) {
                Log.Error("DB", "connect", "Error Connecting:" + err.sqlMessage);
                connections[db] = undefined;
                return rej(err);
            };
            Log.Success("DB", "connect", "Connected to Refinery SQL!");
            return res(connections[db]);
        });

    })
}

module.exports.query = (db,sql) => {
    return new Promise((res, rej) => {
        if (connections[db] == undefined) {
            Log.Error("DB", "query", "Connection object is null, can not query");
            return rej();
        }
        connections[db].query(sql,function (err, result) {
            if (err) {
                Log.Error("DB", "query", "Error Qeurying:" + err.sqlMessage);
                return rej(err);
            };
            //Log.Success("DB", "connect", "Connected to Refinery SQL!");
            return res(result);
        });

    })
}




module.exports.buildInsert = (table, fields, values) =>{
    return `INSERT INTO ${table} (${fields.join(",")}) VALUES (${values.map(val=>"'"+val+"'").join(",")})`
}
module.exports.connections = connections;