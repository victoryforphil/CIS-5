const Logger = require("disnode-logger").static;
const Express = require("express");
const Router = Express.Router();
const cors = require('cors');
const session = require("express-session");
const config = require("../config");

var corsOptions = {
    credentials: true,
    //origin: ["http://disnode.dev", /\.disnode\.dev$/]
};
const AuthHandler = require("../handlers/AuthHandler")


Router.use(cors(corsOptions));
Router.options('*', cors(corsOptions))

/*
Router.post('/signup', (req, res, next) => {
    AuthHandler.passport.authenticate('local-signup', {
        failureFlash: true // allow flash messages
    }, (err, user, info) => {
        if (err) {
            const reply = {
                type: "ERR",
                code: err.code,
                message: err.message,
                data: err
            }
            return res.json(reply).status(402);
        }
        const reply = {
            type: "SUC",
            code: "SIGNUP_SUCCESS",
            message: "Successfully Created User!",
            data: user
        }
        return res.json(reply).status(200);


    })(req, res, next);
});

*/
Router.post('/login', (req, res, next) => {
    AuthHandler.passport.authenticate('local-login', {
        failureFlash: true // allow flash messages
    }, (err, user, info) => {

        if (err) {
            const reply = {
                type: "ERR",
                code: err.code,
                message: err.message,
                data: err
            }
            return res.json(reply).status(402);
        }

        req.logIn(user, function (err) {
            if (err) {
                const reply = {
                    type: "ERR",
                    code: err.code,
                    message: err.message,
                    data: err
                }
                return res.json(reply).status(500);
            }
            const reply = {
                type: "SUC",
                code: "LOGIN_SUCCESS",
                message: "Successfully Logged In!",
                data: user
            }
            return res.json(reply).status(200);
        });


    })(req, res, next);
});
Router.get("/signout", isLoggedIn, (req, res) => {
    req.session.destroy(function (err) {
        if (err) {
            const reply = {
                type: "ERR",
                code: err.code,
                message: err.message,
                data: err
            }
            return res.json(reply).status(500);
        }
        const reply = {
            type: "SUC",
            code: "SIGNOUT_SUCC",
            message: "Successfully Signed Out In!",
            data: new Date()
        }
        return res.json(reply).status(200);
    });
});

Router.get('/check', isLoggedIn, (req, res) => {
    const reply = {
        type: "SUCC",
        code: "AUTH_ENABLED",
        message: "You are logged in",
        data: req.user["_id"]
    }
    return res.json(reply).status(200);
});

Router.get('/user', isLoggedIn, (req, res) => {
    const reply = {
        type: "SUCC",
        code: "AUTH_USER",
        message: "Welcome " + req.user.name,
        data: req.user
    }
    return res.json(reply).status(200);
});

function isLoggedIn(req, res, next) {

    // if user is authenticated in the session, carry on 
    if (req.isAuthenticated())
        return next();

    // if they aren't redirect them to the home page
    const reply = {
        type: "ERR",
        code: "AUTH_FAILED",
        message: "This route you are not authorized for.",
        data: req.isAuthenticated()
    }
    return res.json(reply).status(402);
}
module.exports = Router;
