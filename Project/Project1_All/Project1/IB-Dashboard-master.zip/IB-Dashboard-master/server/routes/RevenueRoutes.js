const Logger = require("disnode-logger").static;
const Express = require("express");
const Router = Express.Router();
const cors = require('cors');
const session = require("express-session");
const config = require("../config");
const RouteUtils = require("../utils/routeUtil");
const SQL = require("../utils/sql")

var corsOptions = {
    credentials: true,
    //origin: ["http://disnode.dev", /\.disnode\.dev$/]
};


Router.use(cors(corsOptions));
Router.options('*', cors(corsOptions))

//Create Room
/*
name - string
desc  - string
maxPlayers - int
isOpened - bool
*/



Router.get("/",async (req,res)=>{

    
    var query = `SELECT * from yt_client WHERE ib=1`;
    var result = await SQL.query("client_data", query);
    result = result.map((item)=>{return {name: item.username, id: item.client_id}})
    const reply = {     
        type: "SUCC",
        code: "GET_REV",
        message:"Found Rev:",
        data: result
    }

    return res.json(reply)

});



Router.get("/:id",async (req,res)=>{
    var chan = req.params.id;
    if(!chan){
        Logger.Warning("RevenueRoutes", "Get", "No ID Provided")
        const reply = {     
            type: "ERR",
            code: "REV_NO_ID",
            message:"Please enter a channel ID",
            data: req.params
        }
        return res.json(reply)
        
    }
    Logger.Info("RevenueRoutes", "Get", "Getting Rev for: " + chan)

    var query = `SELECT * from yt_dailyrev WHERE id='${chan}' ORDER BY day DESC LIMIT 10`;
    var result = await SQL.query("client_data",query);
    const reply = {     
        type: "SUCC",
        code: "GET_REV",
        message:"Found Rev: " +chan,
        data: result
    }
    Logger.Success("RevenueRoutes", "Get", "Got Scrape for: " + chan)
    return res.json(reply)
    

});






module.exports = Router;