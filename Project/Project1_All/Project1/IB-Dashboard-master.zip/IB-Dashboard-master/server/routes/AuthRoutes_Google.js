const Logger = require("disnode-logger").static;
const Express = require("express");
const Router = Express.Router();
const cors = require('cors');
const session = require("express-session");
const config = require("../config");

var corsOptions = {
    credentials: true,
    //origin: ["http://disnode.dev", /\.disnode\.dev$/]
};
const AuthHandler = require("../handlers/AuthHandler_Google")


Router.use(cors(corsOptions));
Router.options('*', cors(corsOptions))


Router.get('/google', (req, res, next) => {
    AuthHandler.passport.authenticate('google-login', {
        scope: ['https://www.googleapis.com/auth/plus.login', 
        'https://www.googleapis.com/auth/yt-analytics.readonly',
         'https://www.googleapis.com/auth/yt-analytics-monetary.readonly', 
         'https://www.googleapis.com/auth/youtube',
         'https://www.googleapis.com/auth/youtubepartner'] 
    }, (err, user, info) => {

        if (err) {
            const reply = {
                type: "ERR",
                code: err.code,
                message: err.message,
                data: err
            }
            return res.json(reply).status(402);
        }

        req.logIn(user, function (err) {
            if (err) {
                const reply = {
                    type: "ERR",
                    code: err.code,
                    message: err.message,
                    data: err
                }
                return res.json(reply).status(500);
            }
            const reply = {
                type: "SUC",
                code: "LOGIN_SUCCESS",
                message: "Successfully Logged In!",
                data: user
            }
            return res.json(reply).status(200);
        });


    })(req, res, next);
});

Router.get('/google/callback', (req, res, next) => {
    AuthHandler.passport.authenticate('google-login', {
        
    }, (err, user, info) => {

        if (err) {
            const reply = {
                type: "ERR",
                code: err.code,
                message: err.message,
                data: err
            }
            return res.json(reply).status(402);
        }

        req.logIn(user, function (err) {
            if (err) {
                const reply = {
                    type: "ERR",
                    code: err.code,
                    message: err.message,
                    data: err
                }
                return res.json(reply).status(500);
            }
            const reply = {
                type: "SUC",
                code: "LOGIN_SUCCESS",
                message: "Successfully Logged In!",
                data: user
            }
            return res.redirect("/dashboard.html");
        });


    })(req, res, next);
});
Router.get("/signout", isLoggedIn, (req, res) => {
    req.session.destroy(function (err) {
        if (err) {
            const reply = {
                type: "ERR",
                code: err.code,
                message: err.message,
                data: err
            }
            return res.json(reply).status(500);
        }
        const reply = {
            type: "SUC",
            code: "SIGNOUT_SUCC",
            message: "Successfully Signed Out In!",
            data: new Date()
        }
        return res.json(reply).status(200);
    });
});

Router.get('/check', isLoggedIn, (req, res) => {
    const reply = {
        type: "SUCC",
        code: "AUTH_ENABLED",
        message: "You are logged in",
        data: req.user
    }
    return res.json(reply).status(200);
});

Router.get('/user', isLoggedIn, (req, res) => {
    const reply = {
        type: "SUCC",
        code: "AUTH_USER",
        message: "Welcome " + req.user.name,
        data: req.user
    }
    return res.json(reply).status(200);
});

function isLoggedIn(req, res, next) {

    // if user is authenticated in the session, carry on 
    if (req.isAuthenticated())
        return next();

    // if they aren't redirect them to the home page
    const reply = {
        type: "ERR",
        code: "AUTH_FAILED",
        message: "This route you are not authorized for.",
        data: req.isAuthenticated()
    }
    return res.json(reply).status(402);
}
module.exports = Router;