module.exports = {
    db: {
        host: "35.185.201.252:27017/ib",
        username: "ibapp",
        pass: "htu4gvu0f03nf"
    },
    secret: "34a5s6yu9hdjnasd",
    port: 7001,
    staticHost: true,
    google:{
        clientId: "1022061610414-ug9o1tcekpi41f5eok42j8re1b8sheqk.apps.googleusercontent.com",
        clientSecret:"oi0VGLqKPIYWHecbGaXCJLbD",
        configUrl: "http://localhost:7001/auth/google/callback"
    },
    sql:{
        host:"35.223.33.166",
        user:"refinery-app",
        password:"@iy6cjmmRC73Yiyeb2dX",
        charset : 'utf8mb4'
    }
}
